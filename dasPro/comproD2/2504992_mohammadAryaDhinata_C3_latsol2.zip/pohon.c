#include <stdio.h>

int main(){
	int i, j, k, l, b, c;
	scanf("%d %d", &c, &b);
	
    for(i = 0; i < c/2+1 ; i++) {
        for(j = 0; j < c/2-i ; j++) {
            printf(" "); 
        }
        for(k = 0; k < 2*i+1; k++) {
            printf("*");
        }
    printf("\n");
	}
	
	printf("%d", 9*4/10 );
	
	return 0;
}