#include <stdio.h>

int main(){
	int arr[1028];
	int n; 
	float sum, hasil;

	scanf("%d", &n);
	for(int i = 0; i < n; i++){
		scanf("%d", &arr[i]);
	}
	
	int max, min;
	max = arr[0];
	min = arr[0];
	for(int i = 0; i < n; i++){
		if(max < arr[i]){
			max = arr[i];
		}
	}		
	for(int i = 0; i < n; i++){
		if(min > arr[i]){
			min = arr[i];
		}
	}
	
	
	for(int i = 0; i < n; i++){
		sum += arr[i];
	}
	
	hasil = sum/n;
	
	int cUp, cDown;
	cUp = 0;
	cDown = 0;
	for(int i = 0; i < n; i++){
		if(hasil > arr[i]){
			cUp++;
		}
	}	
	for(int i = 0; i < n; i++){
		if(hasil < arr[i]){
			cDown++; 
		}
	}
	
	printf("Nilai terendah: %d\n", min);
	printf("Nilai tertinggi: %d\n", max);
	printf("Rata-rata nilai: %0.2f\n", hasil);
	printf("Jumlah siswa di atas rata-rata: %d\n", cUp);
	printf("Jumlah siswa di bawah rata-rata: %d\n", cDown);
	
	return 0;
}