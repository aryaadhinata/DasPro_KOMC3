#include <stdio.h>
#include <string.h>

void ASCII(char arr[][513], int j);